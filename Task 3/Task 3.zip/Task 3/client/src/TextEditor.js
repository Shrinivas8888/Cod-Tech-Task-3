import React from 'react';

function TextEditor() {
  return (
    <div>
      <h1>Text Editor</h1>
    </div>
  );
}

export default TextEditor; // ✅ MUST be exported
